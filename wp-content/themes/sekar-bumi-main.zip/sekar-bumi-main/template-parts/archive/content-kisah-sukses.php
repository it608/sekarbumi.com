<?php
if( is_post_type_archive( 'kisah-sukses' ) ){
	$attribute = 'data-uk-scrollspy="cls:uk-animation-slide-bottom"';
}
?>
<div class="uk-card" <?php echo !empty( $attribute ) ? esc_attr( $attribute ) : ''; ?>>
	<div class="uk-box-shadow-medium uk-border-rounded uk-overflow-hidden uk-text-center">
		<div class="cf-ks-thumbnail">
			<?php the_post_thumbnail(); ?>
		</div>
		<div class="cf-ks-post-content">
			<h1 class="cf-post-title uk-margin-medium-bottom"><?php the_title(); ?></h1>
			<p class="cf-post-excerpt uk-margin-medium-bottom uk-margin-remove-top"><?php sekarbumi_post_excerpt( 19 ); ?></p>
			<a href="<?php esc_url( the_permalink() )?>" class="cf-btn-block uk-border-rounded"><?php printf( '%s', __( 'Baca Lebih Lanjut', 'sekarbumi' ) ); ?></a>
		</div>
	</div>
</div>