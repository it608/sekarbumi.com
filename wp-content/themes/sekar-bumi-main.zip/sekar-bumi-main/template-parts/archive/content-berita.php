<div>
	<div class="cf-berita--item uk-flex uk-box-shadow-medium uk-border-rounded uk-overflow-hidden" data-uk-scrollspy="cls:uk-animation-slide-bottom">
		<div class="uk-width-1-3@s">
			<div class="cf-news-thumbnail">
				<?php the_post_thumbnail( 'full' ); ?>
			</div>
		</div>
		<div class="uk-width-expand@s cf-news-content">
			<h1 class="cf-post-title uk-margin-bottom"><?php the_title(); ?></h1>
			<p class="uk-margin-remove-top"><?php sekarbumi_post_excerpt( 19 ); ?></p>
			<a href="<?php esc_url( the_permalink() )?>" target="_blank" class="cf-news-btn"><?php printf( '%s', __( 'Baca Lebih Lanjut', 'sekarbumi' ) ); ?></a>
		</div>
	</div>
</div>