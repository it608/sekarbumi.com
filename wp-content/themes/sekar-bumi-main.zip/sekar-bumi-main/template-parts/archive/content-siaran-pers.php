
<?php
	$press_file_link	= get_post_meta( get_the_ID(), 'press_file_link', true );
?>
	<div>
		<div class="cf-siaran-pers--item uk-flex uk-box-shadow-medium uk-border-rounded uk-overflow-hidden" data-uk-scrollspy="cls:uk-animation-slide-bottom">
			<div class="uk-width-1-3@s">
				<div class="cf-news-thumbnail">
					<?php 
						if( has_post_thumbnail() ){
							the_post_thumbnail();
						} 
					?>
				</div>
			</div>
			<div class="uk-width-expand@s cf-news-content">
				<h1 class="cf-post-title uk-margin-bottom"><?php the_title(); ?></h1>
				<p class="uk-margin-remove-top"><?php sekarbumi_post_excerpt( 19 ); ?></p>
				<a href="<?php echo !empty( $press_file_link ) ? esc_url( $press_file_link ) : ''; ?>" download target="_blank" class="cf-news-btn"><?php printf( '%s', __( 'Baca Lebih Lanjut', 'sekarbumi' ) ); ?></a>
			</div>
		</div>
	</div>