<?php
$skbm_report_link	= get_post_meta( get_the_ID(), 'skbm_report_link', true );
?>
<div>
  <div class="skbm-cpt-card uk-box-shadow-medium uk-box-shadow-hover-large uk-border-rounded uk-overflow-hidden uk-text-center" data-uk-scrollspy="cls:uk-animation-slide-bottom">
    <span class="skbm-cpt-card__misc"><?php printf( '%s', __( 'Public Disclosure', 'sekarbumi' ) ); ?></span>
    <h1 class="skbm-cpt-card__post-title uk-margin-bottom"><?php the_title(); ?></h1>
    <a href="<?php echo !empty( $skbm_report_link ) ? esc_url( $skbm_report_link ) : ''; ?>" target="_blank" class="skbm-cpt-card__button uk-border-rounded"><?php _e( 'Read The Report', 'sekarbumi' ); ?></a>
  </div>
</div>